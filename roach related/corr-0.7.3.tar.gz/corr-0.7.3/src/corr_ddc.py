"""
Functions for controlling a narrowband correlator with a digital downconverter to select the band of interest.

Author: Paul Prozesky
"""
